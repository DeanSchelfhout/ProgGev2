﻿namespace GymTestAPI.DTO
{
    public class CyclingSessionMonthDTO
    {
        public string Month { get; set; }
        public List<CyclingSessionDTO> CyclingSessionDTO { get; set; }
    }
}
