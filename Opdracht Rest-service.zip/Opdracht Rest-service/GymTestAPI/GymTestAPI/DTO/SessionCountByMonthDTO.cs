﻿namespace GymTestAPI.DTO
{
    public class SessionCountByMonthDTO
    {
        public string Month { get; set; }
        public int SessionCount { get; set; } = 0;
    }
}
